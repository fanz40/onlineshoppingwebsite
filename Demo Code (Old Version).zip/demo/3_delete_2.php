<?php
session_start();

try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}

$command = "SELECT * FROM zf_shop_owner where username = '$_SESSION[username]'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
# get values
$store_id = $row['store_id'];

$product_id = $_POST['product_id'];

$sql = "DELETE FROM zf_product WHERE product_id = '$product_id'";
$stmt = $dbh->prepare($sql);
$result = $stmt->execute();

if ($result)
$message = "<p>You have successfully deleted a product, click <b><a href='3_manage_store.php'>here</a></b> to go back to your product.</p>";
else
$message = "<p>Please try again...<a href='3_manage_store.php'>Go Back</p>";

echo "<p>$message</p>";
?>

<html>
    <head>
		<title>Delete Product</title>
		<link rel="stylesheet" href="css/style.css">
	</head>
</html>
