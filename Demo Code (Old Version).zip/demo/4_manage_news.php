<!-- This page is the manage news page for admin -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

$command = "SELECT * FROM zf_news";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>
    <div class="center">
      <h2>Manage News:</h2>
      <hr>
    </div>

    <div class="margin">
      <nav>
        <h2>
          <a href="4_admin.php">< Back</a>
        </h2>
      </nav>

    <h2>Your products:</h2>

    <a href="4_update_news.php">Edit News</a> |
    <a href="4_delete_news.php">Delete News</a>
    <br><br>

    <?php
    $SQL = "SELECT * FROM zf_news";
    $display = $connection-> query($SQL);

    if ($display-> num_rows > 0) {
      while ($row = $display-> fetch_assoc()) {
        echo '<b>News ID:</b> '.$row["news_id"]
        .'<br>
        <b>News Name:</b> '.$row["news_name"]
        .'<br>
        <b>News Content:</b> '.$row["news_content"]
        .'<br>
        <b>Time:</b> '.$row["time"]
        .'<br>
        <b>Author:</b> '.$row["author"].'<hr>';
    				}
    			}
    			else {
    				echo "There is no news yet!";
    			}

    			$connection-> close();
    ?>
    <a href='4_add_news.php'>Add News</a>
  </body>
</html>
