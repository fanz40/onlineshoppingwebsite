<!-- This is the search page for customer -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Search Results</h1>
    <hr>
  </div>

  <div class="margin">
  <nav>
    <h2>
      <a href="2_customer.php">Home</a> |
      <a href="2_orders.php">Your Orders</a> |
      <a href="2_favorite.php">Your Favorites</a>
    </h2>
  </nav>

  <h3>Results:</h3>

  <a href = "2_add_favorite.php">Add your Favorite Store</a>

  <?php
  $search = $_POST['search'];

  $SQL = "SELECT * FROM zf_shop_owner WHERE store_name LIKE '%$search%' ORDER BY store_name";
  $display = $connection-> query($SQL);
  # Display detail
  if ($display-> num_rows > 0) {
    while ($row = $display-> fetch_assoc()) {
      echo '<h3>
              <a href = 2_detail.php?id='.$row["store_id"].'>
                <img src="img/store.png" height="50" width="50">
                <br>
                Store ID: '.$row["store_id"].'<br>
                Store Name: '.$row["store_name"].'<br>
                Major Brand: '.$row["major_brand"].'
              </a>
            </h3><hr>';
          }
        }
        else {
  				echo "There is no result for <b>".$search."</b>, Click <b><a href='2_customer.php'>here</a></b> to go back to homepage.";
  			}
        $connection-> close();
        ?>
      </body>
</html>
