<?php
# Set session for the user
session_start();
$_SESSION["username"] = $_POST["username"];
# connect to the database
try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}
# Get the post to see the user role
$radioVal = $_POST["thing"];
if($radioVal == "customer"){
	$command = "SELECT * FROM zf_customer where username = '$_SESSION[username]'";
}
else if($radioVal == "shop"){
	$command = "SELECT * FROM zf_shop_owner where username = '$_SESSION[username]'";
}
# Excute the sql command line
$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>

  <body>
		<!-- Set a form to 1_forgot_3.php if user is a customer -->
    <?php
      if($radioVal == "customer"){
      	?>
        <form action="1_forgot3.php" method="POST">
          <p>
            What's the secure question answer for: <b><?php echo $row['secure_question']; ?></b>
          </p>
          <input type="text" required name="answer"><br>
          <input type="radio" name="thing" value="customer" checked> Customer<br>
          <button type="submit">Next</button>
        </form>
        <?php
      }
			#Set a form to 1_forgot_3.php if user is a shop owner
      else if($radioVal == "shop"){
        ?>
        <form action="1_forgot3.php" method="POST">
          <p>
            What's the secure question answer for: <?php echo $row['secure_question']; ?>
          </p>
          <input type="text" required name="answer"><br><br>
          <input type="radio" name="thing" value="shop"> Shop Owner<br>
          <button type="submit">Next</button>
        </form>
        <?php
			}
      ?>
  </body>
</html>
