<!-- This page is the manage store page for shop owner -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

$command = "SELECT store_id FROM zf_shop_owner where username = '$_SESSION[username]'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

$store_id = $row['store_id'];
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>
    <div class="center">
      <h2>Products from your store:</h2>
      <hr>
    </div>

    <div class="margin">
      <nav>
        <h2>
          <a href="3_shop.php">< Back</a>
        </h2>
      </nav>

    <h2>Your products:</h2>

    <a href="3_edit.php">Edit Product</a> |
    <a href="3_delete.php">Delete Product</a>
    <br><br>

    <?php
    $SQL = "SELECT * FROM zf_product WHERE store_id = '$store_id'";
    $display = $connection-> query($SQL);

    # get values for store
    if ($display-> num_rows > 0) {
      while ($row = $display-> fetch_assoc()) {
        echo '<b>Product ID:</b> '.$row["product_id"].'<br>'.$row["product_name"].' --- $'.$row["product_price"].'<hr>';
    				}
    			}
    			else {
    				echo "You don't have any product yet!";
    			}

    			$connection-> close();
    ?>
    <a href='3_new_product.php'>Add New Product</a>
  </body>
</html>
