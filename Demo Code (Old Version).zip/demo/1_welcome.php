<!-- This is the welcome page for all type of user -->
<?php
# Set session for the user
session_start();
$_SESSION["username"] = $_POST["username"];
$_SESSION["password"] = $_POST["password"];
# connect to the database
try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}
# Get user role
$radioVal = $_POST["thing"];
if($radioVal == "customer"){
	$command = "SELECT * FROM zf_customer where username = '$_SESSION[username]' and password = '$_SESSION[password]'";
}
else if($radioVal == "shop"){
	$command = "SELECT * FROM zf_shop_owner where username = '$_SESSION[username]' and password = '$_SESSION[password]'";
}else if($radioVal == "admin"){
	$command = "SELECT * FROM zf_administrator where username = '$_SESSION[username]' and password = '$_SESSION[password]'";
}
# excute the sql command
$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>

	<body>
		<?php
		# Direct to different site with different user.
			if($radioVal == "customer"){
				if($row['username'] == $_SESSION["username"] && $row['password'] == $_SESSION["password"]){

				echo"<p>Hello,  ".$row['username']."!</p>";

				echo "<p>Click <b><a href='2_customer.php'>here</a></b> to go to your home page.</p>";

			  }else{
				echo "Please try again...<b><a href='index.html>Go back</a></b>";
			  }
			}
			else if($radioVal == "shop"){
				if($row['username'] == $_SESSION["username"] && $row['password'] == $_SESSION["password"]){

				echo"<p>Hello, ".$row['username']."!</p>";

				echo "<p>Click <b><a href='3_shop.php'>here</a></b> to go to your home page.</p>";
			  }
				else{
				echo "Please try again...<b><a href='index.html>Go back</a></b>";
			  }
			}
			else if($radioVal == "admin"){
				if($row['username'] == $_SESSION["username"] && $row['password'] == $_SESSION["password"]){

					echo"<p>Hello, ".$row['username']."!</p>";

					echo "<p>Click <b><a href='4_admin.php'>here</a></b> to go to your home page.</p>";
			  }
				else{
				echo "Please try again...<b><a href='index.html>Go back</a></b>";
			  }
			}
			?>
	</body>
</html>
