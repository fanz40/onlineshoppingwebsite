<!DOCTYPE HTML>
<html>
  <head>
  	<title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>

  <body>
    <!-- Get user type and post value -->
    <?php
    $radioVal = $_POST["thing"];
    if($radioVal == "customer"){
      ?>
      <h1>Customer Registration</h1>
      <form action="1_registration3.php" method="POST">
        Create your Username:<br>
        <input type="int" required name="username"><br>
        Create your password:<br>
        <input type="int" required name="password"><br><br>
        Confirm your new password:<br>
        <input type="int" required name="cPassword"><br><br>
        Set your secure question:<br>
        <input type="int" required name="secure_question"><br><br>
        Set your question answer:<br>
        <input type="int" required name="answer"><br><br>
        Confirm your question answer:<br>
        <input type="int" required name="cAnswer"><br><br>
        <input type="radio" name="thing" value="customer" checked>Customer<br>
        <button type="submit">Next</button>
      </form>
      <?php
    }
    else{
      ?>
      <h1>Shop Owner Registration</h1>
      <form action="1_registration3.php" method="POST">
        Create your Username:<br>
        <input type="int" required name="username"><br>
        Create your password:<br>
        <input type="int" required name="password"><br><br>
        Confirm your new password:<br>
        <input type="int" required name="cPassword"><br><br>
        Set your secure question:<br>
        <input type="int" required name="secure_question"><br><br>
        Set your question answer:<br>
        <input type="int" required name="answer"><br><br>
        Confirm your question answer:<br>
        <input type="int" required name="cAnswer"><br><br>
        Enter your store name:<br>
        <input type="int" required name="store_name"><br><br>
        Enter your major brand:<br>
        <input type="int" required name="major_brand"><br><br>
        Choose your category:<br>
        <input type="int" required name="category"><br><br>
        <input type="radio" name="thing" value="shop" checked> Shop Owner<br>
        <button type="submit">Next</button>
      </form>
      <?php
    }
    ?>
  </body>
</html>
