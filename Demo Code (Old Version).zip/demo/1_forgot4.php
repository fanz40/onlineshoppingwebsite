<?php
# Set session for the user
session_start();
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>

  <body>
    <!-- Set a form to 1_forgot_4.php if user is a customer -->
    <?php
    $radioVal = $_POST["thing"];
    if($radioVal == "customer"){
      ?>
      <form action="1_forgot5.php" method="POST">
        Enter your new password:<br>
        <input type="password" required name="password"><br>
        <input type="radio" name="thing" value="customer" checked>Customer<br>
        <button type="submit">Next</button>
      </form>
      <?php
    }
    #Set a form to 1_forgot_4.php if user is a shop owner
    else{
      ?>
      <form action="1_forgot5.php" method="POST">
        Enter your new password:<br>
        <input type="text" required name="password"><br>
        <input type="radio" name="thing" value="shop"> Shop Owner<br>
        <button type="submit">Next</button>
      </form>
      <?php
    }
    ?>
  </body>
</html>
