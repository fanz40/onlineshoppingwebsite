<!-- This page till 4_update_news_2.php is the update news page for admin -->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Update News</h1>
    <hr>
  </div>

  <div class="margin">
    <h2><a href="4_manage_news.php">< Back</a></h2>


    <form action="4_update_news_2.php" method="POST">
      <label>Enter News ID:</label>
      <br>
      <input type="text" required name="news_id">
      <br>
      <label>Enter Updated News Name:</label>
      <br>
      <input type="text" name="news_name">
      <br>
      <label>Enter Updated News Content:</label>
      <br>
      <input type="text" required name="news_content">
      <br>
      <label>Enter Updated Author:</label>
      <br>
      <input type="text" required name="author">
      <br>
      <button type="submit">Update</button>
		</form>
  </div>
</body>
</html>
