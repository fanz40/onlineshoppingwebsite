<!-- This page till 4_delete_customer_2.php is the delete user page for admin -->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Delete Customer</h1>
    <hr>
  </div>

  <div class="margin">
    <h2><a href="4_manage_customer.php">< Back</a></h2>

    <form action="4_delete_customer_2.php" method="POST">
      <label>Enter customer ID</label>
      <br>
      <input type="text" required name="customer_id">
      <br>
      <button type="submit">Delete</button>
    </form>
  </div>
</body>
</html>
