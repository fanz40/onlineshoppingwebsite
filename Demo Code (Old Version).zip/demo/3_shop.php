<!-- This is the shop home page -->
<?php
session_start();
echo '<div class="right">Hi, '.$_SESSION["username"].'! <a href="1_logout.php">Log out</a></div>';
?>

<!DOCTYPE html>
<html>

<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Shop Owner Homepage</h2>
    <hr>

    <nav>
      <h2>
        <a href="3_update_status.php">Update Status</a> |
        <a href="3_manage_store.php">Manage Store</a>
    </h2>
    </nav>
  </div>
</body>
</html>
