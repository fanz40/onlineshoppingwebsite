<!-- This page till 3_edit_2.php is the function of update product for shop owner -->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Update Product</h1>
    <hr>
  </div>

  <div class="margin">
    <h2><a href="3_manage_store.php">< Back</a></h2>


    <form action="3_edit_2.php" method="POST">
      <label>Enter Product ID</label>
      <br>
      <input type="text" required name="product_id">
      <br>
      <label>Enter New Product Name</label>
      <br>
      <input type="text" name="product_name">
      <br>
      <label>Enter New Product Price</label>
      <br>
      <input type="text" required name="product_price">
      <br>
      <button type="submit">Update</button>
		</form>
  </div>
</body>
</html>
