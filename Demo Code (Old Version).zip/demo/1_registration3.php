<?php
# Connect to the database
$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
 ?>
<!DOCTYPE HTML>
<html>
  <head>
  	<title>Registration</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>

  <body>
    <?php
    $radioVal = $_POST["thing"];
    if($radioVal == "shop"){
      $username = $_POST['username'];
      $password = $_POST['password'];
      $secure_question = $_POST['secure_question'];
      $answer = $_POST['answer'];
      $store_name = $_POST['store_name'];
      $major_brand = $_POST['major_brand'];
      $category = $_POST['category'];
      $sql = "INSERT INTO zf_shop_owner (username, password, secure_question, answer, store_name, major_brand, category) VALUES ('$username', '$password', '$secure_question', '$answer', '$store_name', '$major_brand', '$category')";
      $stmt = $dbh->prepare($sql);
      $result = $stmt->execute();
      if ($result)
      $message = "You have successfully created your account, click <b><a href='index.html'>here</a></b> to log in.";
      else
      $message = "Please try again...<a href='index.html'>Go Back</a>";

      echo "<p>$message</p>";

    } else {

      $username = $_POST['username'];
      $password = $_POST['password'];
      $secure_question = $_POST['secure_question'];
      $answer = $_POST['answer'];

      $sql = "INSERT INTO zf_customer (username, password, secure_question, answer) VALUES ('$username', '$password', '$secure_question', '$answer')";

      $stmt = $dbh->prepare($sql);
      $result = $stmt->execute();
      if ($result)
      $message = "You have successfully created your account, click <b><a href='index.html'>here</a></b> to log in.";
      else
      $message = "Please try again...<a href='index.html'>Go Back</a>";

      echo "<p>$message</p>";
    }
    ?>
    <a href="index.html">Login</a>
  </body>
</html>
