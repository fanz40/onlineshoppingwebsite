<!-- This page is the charge page for customer purchase purpose. -->
<?php
session_start();

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

$id = $_GET['id'];

$command = "SELECT * FROM zf_product where product_id = '$id'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

$product_name = $row['product_name'];
$product_price = $row['product_price'];
$store_id = $row['store_id'];

$command = "SELECT * FROM zf_customer where username = '$_SESSION[username]'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

$customer_id = $row['customer_id'];

require_once('vendor/autoload.php');

  \Stripe\Stripe::setApiKey('sk_test_WMIY5WK5FlaBbCdQEFxneMWW00JmXhvgLu');

  // Sanitize POST Array
 $POST = filter_var_array($_POST, FILTER_SANITIZE_STRING);

 $first_name = $POST['first_name'];
 $last_name = $POST['last_name'];
 $email = $POST['email'];
 $token = $POST['stripeToken'];

 // Create Customer In Stripe
 $customer = \Stripe\Customer::create(array(
   "email" => $email,
   "source" => $token
 ));

 // Charge Customer
 $charge = \Stripe\Charge::create(array(
   "amount" => $product_price.'00',
   "currency" => "cad",
   "description" => $product_name,
   "customer" => $customer->id
 ));

 $sql = "INSERT INTO zf_payment (transaction_id, first_name, last_name, email_address) VALUES ('$token', '$first_name', '$last_name', '$email')";

 $stmt = $dbh->prepare($sql);
 $result = $stmt->execute();

 $sql = "INSERT INTO zf_transaction (transaction_id, customer_id, product_name, amount, store_id) VALUES ('$token', '$customer_id', '$product_name', '$product_price', '$store_id')";

 $stmt = $dbh->prepare($sql);
 $result = $stmt->execute();

header('Location: 2_success.php?tid='.$charge->id.'&product='.$charge->description);
