<!-- This page is the manage customer page for admin -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>
    <div class="center">
      <h2>Users of Hamilton Easy Repair:</h2>
      <hr>
    </div>

    <div class="margin">
      <nav>
        <h2>
          <a href="4_admin.php">< Back</a>
        </h2>
      </nav>

    <h2>Users:</h2>

    <a href="4_update_customer.php">Edit Cutsomer</a> |
    <a href="4_delete_customer.php">Delete Customer</a>
    <br><br>

    <?php
    $SQL = "SELECT * FROM zf_customer";
    $display = $connection-> query($SQL);

    if ($display-> num_rows > 0) {
      while ($row = $display-> fetch_assoc()) {
        echo '<b>Customer ID:</b> '.$row["customer_id"]
        .'<br>
        <b>Username:</b> '.$row["username"]
        .'<br>
        <b>Password:</b> '.$row["password"]
        .'<br>
        <b>Secure Question:</b> '.$row["secure_question"]
        .'<br>
        <b>Answer:</b> '.$row["answer"].'<hr>';
    				}
    			}
    			else {
    				echo "There is no customer user yet!";
    			}

    			$connection-> close();
    ?>
  </body>
</html>
