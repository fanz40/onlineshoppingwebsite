<?php
session_start();
echo 'Hello, '.$_SESSION["username"].'!';
$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>New Favorite</title>
    <link rel="stylesheet" type="text/css" href="style/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>

  <body>

    <?php

    $command = "SELECT * FROM zf_customer where username = '$_SESSION[username]'";

    $stmt = $dbh->prepare($command);
    $stmt->execute();
    $row = $stmt->fetch();

    $customer_id = $row['customer_id'];
    $store_id = $_POST['store_id'];

    $sql = "INSERT INTO zf_favorite (customer_id, store_id) VALUES ('$customer_id', '$store_id')";

    $stmt = $dbh->prepare($sql);
    $result = $stmt->execute();

    if ($result)
    $message = "success";
    else
    $message = "failure";

    echo "<p>$message</p><a href='2_favorite.php'>Go Back</a>";
    ?>
  </body>
</html>
