<!-- This page till 4_add_news_2.php is the add news page for admin -->
<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Add News</h1>
    <hr>
  </div>

  <div class="margin">
    <h2><a href="4_manage_news.php">< Back</a></h2>

    <form action="4_add_news_2.php" method="POST">
      <label>Please enter news name:</label>
      <br>
      <input type="text" required name="news_name">
      <br>
      <label>Please enter news content:</label>
      <br>
      <input type="text" required name="news_content">
      <br>
      <label>Please enter author name:</label>
      <br>
      <input type="text" required name="author">
      <br>
      <button type="submit">Add</button>
    </form>
