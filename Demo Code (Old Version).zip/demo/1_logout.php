<?php
# Set session for the user
session_start();
# Destroy the session
session_destroy();
echo "You have successfully logged out! Click <b><a href='index.html'>here</a></b> to return to the login page.";
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Logout</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
</html>
