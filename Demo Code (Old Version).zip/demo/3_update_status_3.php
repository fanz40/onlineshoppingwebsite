<?php

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>

    <?php
    $id = $_GET['id'];
    $status = $_POST['status'];

    $command = "UPDATE zf_transaction SET status = '$status' WHERE transaction_id = '$id'";

    $stmt = $dbh->prepare($command);
    $stmt->execute();
    $row = $stmt->fetch();

    if ($stmt)
    $message = "<p>You have successfully updated the status, click <b><a href='3_update_status.php'>here</a></b> to go back to your transactions.</p>";
    else
    $message = "failure";

    echo "<p>$message</p>";
    ?>
  </body>
</html>
