<?php
# Set session for the user
session_start();
# connect to the database
try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}
# Get the post to see the user role
$radioVal = $_POST["thing"];
if($radioVal == "customer"){
	$command = "SELECT answer FROM zf_customer where username = '$_SESSION[username]'";
}
else if($radioVal == "shop"){
	$command = "SELECT answer FROM zf_shop_owner where username = '$_SESSION[username]'";
}
# Excute the sql command line
$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>

  <body>
		<!-- Set a form to 1_forgot_4.php if user is a customer -->
    <?php
    if($radioVal == "customer"){
      if($row['answer'] == $_POST["answer"]){
        ?>
        <form action="1_forgot4.php" method="POST">
          <p>
            Success! Please click the button to go to the next page!
          </p>
          <input type="radio" name="thing" value="customer" checked> Customer<br>

          <button type="submit">Next</button>
        </form>
        <?php
      } else {
        echo "Please try again...<a href='index.html'>Back</a>";
      }
    }
		#Set a form to 1_forgot_4.php if user is a shop owner
    else if($radioVal == "shop"){
      if($row['answer'] == $_POST["answer"]){
        ?>
        <form action="1_forgot4.php" method="POST">
          <p>
            Success! Please click the button to go to the next page!
          </p>
          <input type="radio" name="thing" value="shop"> Shop Owner<br>
          <button type="submit">Next</button>
        </form>
        <?php
      } else {
        echo "Please try again...<b><a href='1_forgot2.php'>Back</a></b>";
      }
    }
     ?>
  </body>
</html>
