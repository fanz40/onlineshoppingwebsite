<?php
session_start();
$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>

    <?php
    # get values
      $product_name = $_POST['product_name'];
      $product_price = $_POST['product_price'];
      $username = $_SESSION["username"];

      $command = "SELECT store_id FROM zf_shop_owner where username = '$_SESSION[username]'";

      $stmt = $dbh->prepare($command);
      $stmt->execute();
      $row = $stmt->fetch();

      $store_id = $row['store_id'];

      $sql = "INSERT INTO zf_product (product_name, product_price, store_id) VALUES ('$product_name', '$product_price', '$store_id')";

      $stmt = $dbh->prepare($sql);
      $result = $stmt->execute();

      if ($result)
      $message = "<p>You have successfully added a product, click <b><a href='3_manage_store.php'>here</a></b> to go back to your product.</p>";
      else
      $message = "<p>Please try again...<a href='3_manage_store.php'>Go Back</p>";

      echo "<p>$message</p>";
    ?>
  </body>
</html>
