<!-- This page till 4_update_customer_2.php is the update customer page for admin -->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Update Customer</h1>
    <hr>
  </div>

  <div class="margin">
    <h2><a href="4_manage_customer.php">< Back</a></h2>


    <form action="4_update_customer_2.php" method="POST">
      <label>Enter Cutsomer ID:</label>
      <br>
      <input type="text" required name="customer_id">
      <br>
      <label>Enter New Username:</label>
      <br>
      <input type="text" name="username">
      <br>
      <label>Enter New Password:</label>
      <br>
      <input type="text" required name="password">
      <br>
      <label>Enter New Secure Question:</label>
      <br>
      <input type="text" required name="secure_question">
      <br>
      <label>Enter New Secure Question Answer:</label>
      <br>
      <input type="text" required name="answer">
      <br>
      <button type="submit">Update</button>
		</form>
  </div>
</body>
</html>
