<?php
session_start();

try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}

$news_id = $_POST['news_id'];

$sql = "DELETE FROM zf_news WHERE news_id = '$news_id'";
$stmt = $dbh->prepare($sql);
$result = $stmt->execute();

if ($result)
$message = "<p>You have successfully deleted a news, click <b><a href='4_manage_news.php'>here</a></b> to go back to manage news page.</p>";
else
$message = "<p>Please try again...<a href='4_manage_news.php'>Go Back</p>";

echo "<p>$message</p>";
?>

<html>
    <head>
		<title>Hamilton Easy Repair</title>
		<link rel="stylesheet" href="css/style.css">
	</head>
</html>
