<?php
session_start();

try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}

$news_id = $_POST["news_id"];
$news_name = $_POST["news_name"];
$news_content = $_POST["news_content"];
$author = $_POST["author"];

$command = "UPDATE zf_news SET news_name = '$news_name', news_content = '$news_content', time = CURRENT_TIMESTAMP, author = '$author' WHERE news_id = '$news_id'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

if ($stmt)
$message = "<p>You have successfully updated a news, click <b><a href='4_manage_news.php'>here</a></b> to go back to your product.</p>";
else
$message = "<p>Please try again...<a href='4_manage_news.php'>Go Back</p>";

echo "<p>$message</p>";
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
</html>
