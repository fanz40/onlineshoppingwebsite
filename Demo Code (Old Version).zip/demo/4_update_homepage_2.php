<?php
session_start();

try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}

$content_id = $_POST["content_id"];
$content = $_POST["content"];


$command = "UPDATE zf_home SET content = '$content' WHERE content_id = '$content_id'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

if ($stmt)
$message = "<p>You have successfully updated a homepage content, click <b><a href='4_manage_homepage.php'>here</a></b> to go back to your product.</p>";
else
$message = "<p>Please try again...<a href='4_manage_homepage.php'>Go Back</p>";

echo "<p>$message</p>";
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
</html>
