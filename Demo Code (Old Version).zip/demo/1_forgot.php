<!-- This page till 1_forgot_5 contain the forgot password function. -->
<!DOCTYPE HTML>
<html>
  <head>
  	<title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>
    <h1>Forgot Password</h1>
    <h2>Step 1: Please enter your username</h2>
    <!-- Set a form to 1_forgot_2.php  -->
    <form action="1_forgot2.php" method="POST">
      <label>Are you a "customer" or a "shop owner"?</label>
      <br><br>
      <input type="radio" name="thing" value="customer" checked> Customer
      <br>
      <input type="radio" name="thing" value="shop"> Shop Owner
      <br><br>
      <label>Enter your Username:</label>
      <br>
      <input type="text" required name="username">
      <br><br>
      <button type="submit">Next</button>
    </form>
  </body>
</html>
