<!-- This is the detail page for customer -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

$id = $_GET['id'];

$command = "SELECT * FROM zf_shop_owner where store_id = '$id'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

$store_name = $row['store_name'];
?>
<!-- This is the detail page for customer -->
<!DOCTYPE html>
<html>

<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div class="center">
    <?php echo '<h1>'.$store_name.'</h1>'; ?>
    <hr>
  </div>

  <div class="margin">
    <nav>
      <h2>
        <a href="2_customer.php">Home</a> |
        <a href="2_orders.php">Your Orders</a> |
        <a href="2_favorite.php">Your Favorites</a>
      </h2>
    </nav>

    <p>
      <?php
      echo '<h3>Store Detail:</h3>';

      $SQL = "SELECT * FROM zf_product WHERE store_id = '$id'";
      $display = $connection-> query($SQL);

      if ($display-> num_rows > 0) {
        while ($row = $display-> fetch_assoc()) {
          echo $row["product_name"].': $'.$row["product_price"].' <b><a href="2_pay.php?id='.$row["product_id"].'">Buy</a></b>
          <br><hr>';
              }
            }
            else {
              echo "This store has no item yet, please come back and check again later.";
            }

            $connection-> close();
      ?>
    </p>
  </div>
</body>
</html>
