<?php
session_start();

try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}

$command = "SELECT * FROM zf_shop_owner where username = '$_SESSION[username]'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
# get values for product
$store_id = $row['store_id'];

$product_id = $_POST["product_id"];
$product_name = $_POST["product_name"];
$product_price = $_POST["product_price"];

$command = "UPDATE zf_product SET product_name = '$product_name', product_price = '$product_price' WHERE product_id = '$product_id' AND store_id = '$store_id'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

if ($stmt)
$message = "<p>You have successfully updated a product, click <b><a href='3_manage_store.php'>here</a></b> to go back to your product.</p>";
else
$message = "<p>Please try again...<a href='3_manage_store.php'>Go Back</p>";

echo "<p>$message</p>";
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
</html>
