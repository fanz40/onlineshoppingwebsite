<?php
session_start();
$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
?>

<!DOCTYPE HTML>
<html>
  <head>
  	<title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>

    <?php
      $news_name = $_POST['news_name'];
      $news_content = $_POST['news_content'];
      $author = $_POST['author'];

      $sql = "INSERT INTO zf_news (news_name, news_content, author) VALUES ('$news_name', '$news_content', '$author')";

      $stmt = $dbh->prepare($sql);
      $result = $stmt->execute();

      if ($result)
      $message = "<p>You have successfully added a news, click <b><a href='4_manage_news.php'>here</a></b> to go back to manage news page.</p>";
      else
      $message = "<p>Please try again...<a href='4_manage_news.php'>Go Back</p>";

      echo "<p>$message</p>";
    ?>
  </body>
</html>
