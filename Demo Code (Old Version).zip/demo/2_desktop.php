<!-- This page is the desktop home page -->
<?php
session_start();
echo '<div class="right">Hi, '.$_SESSION["username"].'! <a href="1_logout.php">Log out</a></div>';

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style>
    button {
      padding: 5px 20px;
    }
  </style>
</head>

<body>
  <div class="center">
    <h1>Desktop Department</h1>
    <hr>
  </div>

  <div class="margin">
    <nav>
      <h2>
        <a href="2_customer.php">Home</a> |
        <a href="2_orders.php">Your Orders</a> |
        <a href="2_favorite.php">Your Favorites</a>
      </h2>
    </nav>

    <h3>Desktop:</h3>

    <form action="2_sort.php?id=desktop" method="POST">
      <input type="radio" name="select" value="az" checked>A-Z
      <input type="radio" name="select" value="za">Z-A
      <button type="submit">Sort</button>
    </form>

<a href = "2_add_favorite.php">Add your Favorite Store</a>

<?php
$SQL = "SELECT * FROM zf_shop_owner WHERE category = 'desktop' ORDER BY store_name";
$display = $connection-> query($SQL);

if ($display-> num_rows > 0) {
  while ($row = $display-> fetch_assoc()) {
    echo '<h3>
            <a href = 2_detail.php?id='.$row["store_id"].'>
              <img src="img/store.png" height="50" width="50">
              <br>
              Store ID: '.$row["store_id"].'<br>
              Store Name: '.$row["store_name"].'<br>
              Major Brand: '.$row["major_brand"].'
            </a>
          </h3><hr>';
				}
      }
      else {
				echo "<br><br>There is <b>0</b> desktop store found, please come back and check again later.";
			}

			$connection-> close();
?>





</body>
</html>
