<!-- This page till 2_delete_favorite_2 contain the delete favorite function for customer. -->
<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Delete your Favorite Store</h1>
    <hr>
  </div>

  <div class="margin">
    <form action="2_delete_favorite_2.php" method="POST">
      Please enter the store id:<br>
      <input type="int" required name="store_id"><br>

      <button type="submit">Next</button>
    </form>
  </div>



</body>
</html>
