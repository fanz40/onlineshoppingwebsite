<!-- This is the orders page for customer -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

$command = "SELECT * FROM zf_customer where username = '$_SESSION[username]'";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();

$customer_id = $row['customer_id'];
?>

<!DOCTYPE html>
<html>

<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>View Your Orders</h1>
    <hr>
  </div>

  <div class="margin">
    <nav>
      <h2>
        <a href="2_customer.php">Home</a> |
        <a href="2_orders.php">Your Orders</a> |
        <a href="2_favorite.php">Your Favorites</a>
      </h2>
    </nav>

  <?php
  $SQL = "SELECT * FROM zf_transaction WHERE customer_id = $customer_id";
  $display = $connection-> query($SQL);

  if ($display-> num_rows > 0) {
    while ($row = $display-> fetch_assoc()) {
      echo '<p>
              <b>Transaction ID:</b> '.$row["transaction_id"].'<br>
              <b>Product Name:</b> '.$row["product_name"].'<br>
              <b>Amount:</b> $'.$row["amount"].'<br>
              <b>Status:</b> '.$row["status"].'
            </p><hr>';
  				}
        }
        else {
  				echo "0 display";
  			}
  ?>





</body>
</html>
