<!-- This page till 3_new_2.php is the function of create a new product for shop owner -->
<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Create New Product</h1>
    <hr>
  </div>

  <div class="margin">
    <h2><a href="3_manage_store.php">< Back</a></h2>

    <form action="3_new_product_2.php" method="POST">
      <label>Please enter product name:</label>
      <br>
      <input type="text" required name="product_name">
      <br>
      <label>Please enter product price:</label>
      <br>
      <input type="text" required name="product_price">
      <br>
      <button type="submit">Add</button>
    </form>
