 <?php
 session_start();
 $id = $_GET['id'];
 ?>

 <!DOCTYPE html>
 <html>
   <head>
     <title>Hamilton Easy Repair</title>
     <link rel="stylesheet" type="text/css" href="css/style.css">
   </head>

   <body>
     <form action="3_update_status_3.php?id=<?php echo $id; ?>" method="POST">
       <label>Enter new status and click next:</label><br>
       <input type='text' required name='status'><br>
       <button type="submit">Next</button>
     </form>
   </body>
 </html>
