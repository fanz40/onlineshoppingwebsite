<!-- This page till 1_registration3.php contain the registration function. -->
<!DOCTYPE HTML>
<html>
  <head>
  	<title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  </head>
  <!-- Get user type -->
  <body>
    <h1>Registration Page</h1>
    <form action="1_registration2.php" method="POST">
      Are you registering for "Cutsomer" or as a "Shop Owner"?<br>
      <input type="radio" name="thing" value="customer" checked> Customer<br>
      <input type="radio" name="thing" value="shop"> Shop Owner<br>
      <button type="submit">Next</button>
    </form>
  </body>
</html>
