<!-- This is the customer home page -->
<?php
session_start();
echo '<div class="right">Hi, '.$_SESSION["username"].'! <a href="1_logout.php">Log out</a></div>';

$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style>
    button {
      padding: 5px 20px;
    }
  </style>
</head>

<body>
  <div class="center">
    <h1>Welcome to Hamiton Easy Repair</h1>
    <hr>
  </div>

  <div class="margin">
  <nav>
    <h2>
      <a href="2_customer.php">Home</a> |
      <a href="2_orders.php">Your Orders</a> |
      <a href="2_favorite.php">Your Favorites</a>
    </h2>
  </nav>

    <form action="2_search.php" method="POST">
      Search <input type="text" name="search" required>
      <button type="submit">Go</button>
    </form>



<h2>Category:</h2>

<?php
# Get content 1
$command = "SELECT * FROM zf_home where content_id = 1";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
$content1 = $row['content'];
# Get content 2
$command = "SELECT * FROM zf_home where content_id = 2";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
$content2 = $row['content'];
# Get content 3
$command = "SELECT * FROM zf_home where content_id = 3";

$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
$content3 = $row['content'];
?>

<h3>
  <a href="2_mobile.php"><?php echo $content1; ?></a> |
  <a href="2_desktop.php"><?php echo $content2; ?></a> |
  <a href="2_laptop.php"><?php echo $content3; ?></a>
</h3>

<br>

<h2>News:</h2>

<?php
# Display the news
$SQL = "SELECT * FROM zf_news";
$display = $connection-> query($SQL);

if ($display-> num_rows > 0) {
  while ($row = $display-> fetch_assoc()) {
    echo '<p>'.$row["news_content"].'<br><br>'.$row["time"].'</p><hr>';
				}
      }
      else {
				echo "There is no news yet!";
			}

			$connection-> close();
?>

</body>
</html>
