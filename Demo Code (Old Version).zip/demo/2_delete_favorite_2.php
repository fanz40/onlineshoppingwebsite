<?php
session_start();
$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
?>

<!DOCTYPE HTML>
<html>
  <head>
    <title>Hamilton Easy Repair</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>

  <body>

    <?php

    $store_id = $_POST['store_id'];

    $sql = "DELETE FROM zf_favorite where store_id = '$store_id'";

    $stmt = $dbh->prepare($sql);
    $result = $stmt->execute();

    if ($result)
    $message = "<p>You have successfully deleted <b>".$store_id."</b> from your favorite list, Click <b><a href='2_favorite.php'>here</a></b> to go back to favorite page.</p>";
    else
    $message = "<p>Cann't delete <b>".$store_id."</b> from your favorite list, Click <b><a href='2_favorite.php'>here</a></b> to go back to favorite page.</p>";

    echo $message;
    ?>
  </body>
</html>
