<!-- This page till 2_add_favorite_2.php contain the add favorite function for customer. -->
<?php
session_start();
echo 'Hello, '.$_SESSION["username"].'!';
?>

<h1>Add your Favorite Store</h1>

<form action="2_add_favorite_2.php" method="POST">
  Please enter the store id:<br>
  <input type="int" required name="store_id"><br>

  <input type="submit" value="Confirm">
</form>
