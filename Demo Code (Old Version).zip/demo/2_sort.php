<!-- This is the sort page for customer -->
<?php
session_start();
echo '<div class="right"><a href="1_logout.php">Log out</a></div>';

$connection = mysqli_connect("sql9.freesqldatabase.com", "sql9311971", "JCnTtCxRUu", "sql9311971");
if ($connection-> connect_error) {
  die("Error connecting to database.");
}

$id = $_GET['id'];
?>

<!DOCTYPE html>
<html>

<head>
  <title>Hamilton Easy Repair</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div class="center">
    <h1>Sort Page</h1>
    <hr>
  </div>

  <div class="margin">
    <nav>
      <h2>
        <a href="2_customer.php">Home</a> |
        <a href="2_orders.php">Your Orders</a> |
        <a href="2_favorite.php">Your Favorites</a>
      </h2>
    </nav>

    <h3>Sorted Results:</h3>


<?php
$radioVal = $_POST["select"];
# Display detail
if($radioVal == "az"){
  $SQL = "SELECT * FROM zf_shop_owner WHERE category = '$id' ORDER BY store_name";
  $display = $connection-> query($SQL);

  if ($display-> num_rows > 0) {
    while ($row = $display-> fetch_assoc()) {
      echo '<h3>
              <a href = 2_detail.php?id='.$row["store_id"].'>
                <img src="img/store.png" height="50" width="50">
                <br>
                Store ID: '.$row["store_id"].'<br>
                Store Name: '.$row["store_name"].'<br>
                Major Brand: '.$row["major_brand"].'
              </a>
            </h3><hr>';
  				}
  			}
  			else {
  				echo "There is <b>0</b> ".$id." store found, please come back and check again later.";
  			}

  			$connection-> close();
} else {
  $SQL = "SELECT * FROM zf_shop_owner WHERE category = '$id' ORDER BY store_name DESC";
  $display = $connection-> query($SQL);

  if ($display-> num_rows > 0) {
    while ($row = $display-> fetch_assoc()) {
      echo '<h3>
              <a href = 2_detail.php?id='.$row["store_id"].'>
                <img src="img/store.png" height="50" width="50">
                <br>
                Store ID: '.$row["store_id"].'<br>
                Store Name: '.$row["store_name"].'<br>
                Major Brand: '.$row["major_brand"].'
              </a>
            </h3><hr>';
  				}
  			}
  			else {
  				echo "There is <b>0</b> ".$id." store found, please come back and check again later.";
  			}

  			$connection-> close();
}

?>





</body>
</html>
