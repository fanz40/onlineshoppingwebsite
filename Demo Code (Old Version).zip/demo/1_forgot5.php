<?php
# Set session for the user
session_start();
# connect to the database
try {
		$dbh = new PDO("mysql:host=sql9.freesqldatabase.com;dbname=sql9311971", "sql9311971", "JCnTtCxRUu");
} catch (Exception $e) {
		die("<h2 class = 'error'>Connect Fail</h2>");
}
# Get the post to see the user role
$radioVal = $_POST["thing"];
$password = $_POST["password"];
if($radioVal == "customer"){
	$command = "UPDATE zf_customer SET password = $password WHERE username = '$_SESSION[username]'";
}
else if($radioVal == "shop"){
	$command = "SELECT answer FROM zf_shop_owner where username = '$_SESSION[username]'";
}
# Excute the sql command line
$stmt = $dbh->prepare($command);
$stmt->execute();
$row = $stmt->fetch();
# Echo the information back to the user
if ($stmt)
$message = "<p>You have successfully updated your password, click <b><a href='index.html'>here</a></b> to log in.</p>";
else
$message = "failure";

echo "<p>$message</p>";
?>

<link rel="stylesheet" type="text/css" href="css/style.css">
